# Programa Organick — TODO

## Navegação (Navbar)
- [x] Logo Organick no navbar
- [x] Links: Início, Minha Conta, Sobre nós (em português)
- [x] Navbar com efeito frost/opaco ao rolar
- [x] Menu hambúrguer mobile
- [x] Botão "Entrar" no desktop (redireciona para /login)

## Hero Section (Home)
- [x] Container sticky com altura de viewport inteira
- [x] Vídeo scroll-driven: avança ao rolar, volta ao subir
- [x] Scrubbing suave via requestAnimationFrame
- [x] Texto overlay: "Seja bem-vindo ao" + "Programa Organick"
- [x] Dois botões CTA: "Meu Primeiro Login" e "Já tenho minha conta"
- [x] "Meu Primeiro Login" → /onboarding
- [x] "Já tenho minha conta" → /login
- [x] Responsivo (desktop + mobile)

## Página de Login (/login)
- [x] Campo: "Qual o seu email?"
- [x] Campo: "Qual sua senha?"
- [x] Botão: "Acessar"
- [x] Login via tRPC com JWT session
- [x] Redirect para /members após login

## Primeiro Login / Onboarding (/onboarding)
- [x] Fluxo step-by-step (8 passos)
- [x] userEmail: Qual o seu email? (text)
- [x] userPassword: Crie uma senha (password, mín. 8 caracteres)
- [x] agencyName: Qual o nome da sua agência? (text)
- [x] agencyAgeRange: Há quanto tempo? (single-choice: 4 opções)
- [x] teamSizeRange: Quantas pessoas? (single-choice: 4 opções)
- [x] clientCount: Quantos clientes? (numérico)
- [x] monthlyRevenue: Faturamento médio mensal? (currency R$)
- [x] onboardingCallSlot: Melhor horário para call? (single-choice: 2 opções)
- [x] Botão final: "Dar vida à minha agência"
- [x] Vaso vazio (pot visual) no lado direito
- [x] Criação de conta + salvamento do diagnóstico na submissão
- [x] Redirect para /members após completar

## Sistema de Diagnóstico / Classificação
- [x] Scoring engine em shared/scoring.ts
- [x] Eixo A: Plant Size (tamanho/maturidade da agência)
- [x] Eixo B: Plant Health (saúde operacional/comercial)
- [x] 4 variáveis de scoring: agencyAgeRange, teamSizeRange, clientCount, monthlyRevenue
- [x] Pesos Size: age=10%, team=20%, clients=30%, revenue=40%
- [x] Pesos Health: age=10%, team=20%, clients=20%, revenue=50%
- [x] Ajustes positivos e negativos de saúde
- [x] 3 tiers de tamanho: small (0-34), medium (35-69), large (70-100)
- [x] 2 tiers de saúde: fragile (0-54), healthy (55-100)
- [x] 6 tipos finais de planta:
  - Broto Promissor (small + healthy)
  - Broto em Risco (small + fragile)
  - Planta em Tração (medium + healthy)
  - Tração Instável (medium + fragile)
  - Planta Escalável (large + healthy)
  - Gigante Exausta (large + fragile)

## Personalização com agencyName
- [x] "Diagnóstico da {{agencyName}}"
- [x] "Saúde da {{agencyName}}"
- [x] "Tamanho da {{agencyName}}"
- [x] "A planta da {{agencyName}}"
- [x] "O momento atual da {{agencyName}}"
- [x] Fallback: "sua agência" quando agencyName vazio/null

## Imagens das Plantas
- [ ] plant-broto-promissor.png (small + healthy)
- [ ] plant-broto-em-risco.png (small + fragile)
- [ ] plant-planta-em-tracao.png (medium + healthy)
- [ ] plant-tracao-instavel.png (medium + fragile)
- [ ] plant-planta-escalavel.png (large + healthy)
- [ ] plant-gigante-exausta.png (large + fragile)
- [ ] Colocar em client/public/images/

## Área do Membro / Diagnóstico (/members)
- [x] Header com logo Organick e botão Sair
- [x] Título personalizado: "Diagnóstico da {agencyName}"
- [x] Card de classificação com tipo de planta e descrição
- [x] Badges: tier de tamanho + tier de saúde
- [x] Barras de Saúde e Tamanho com scores reais
- [x] Cards: Equipe, Clientes, Faturamento, Call
- [x] Blocos placeholder: Módulos (Em breve / Bloqueado)
- [x] Imagem da planta correspondente ao tipo
- [x] Fallback se imagem não existir ainda
- [x] Rota protegida

## Backend
- [x] Schema drizzle com users, localCredentials, onboardingResponses
- [x] bcrypt password hashing
- [x] JWT session via cookie
- [x] Mutation: register, login, completeOnboarding
- [x] Query: getDashboard (retorna surveyAnswers)
- [x] Função: getOnboardingResponses

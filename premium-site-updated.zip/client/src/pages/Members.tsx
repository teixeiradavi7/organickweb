import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { LogOut, Building2, Users, TrendingUp, Calendar, Leaf } from "lucide-react";
import { toast } from "sonner";
import {
  calculateDiagnostic,
  parseSurveyAnswers,
  type DiagnosticResult,
} from "@shared/scoring";

// ─── Progress Bar Component ──────────────────────────────────────────────────

function ProgressBar({
  label,
  value,
  maxValue,
  color,
}: {
  label: string;
  value: number;
  maxValue: number;
  color: string;
}) {
  const percentage = Math.min(100, Math.max(0, (value / maxValue) * 100));
  return (
    <div>
      <div className="flex items-center justify-between mb-1.5">
        <span className="text-[13px] font-medium text-foreground/60">{label}</span>
        <span className="text-[12px] font-semibold text-foreground/40">
          {Math.round(value)}/100
        </span>
      </div>
      <div className="h-2.5 bg-neutral-100 rounded-full overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-1000 ease-out"
          style={{ width: `${percentage}%`, backgroundColor: color }}
        />
      </div>
    </div>
  );
}

// ─── Label helpers ───────────────────────────────────────────────────────────

function getAgencyAgeLabel(id: string): string {
  const map: Record<string, string> = {
    less_than_3_months: "Menos de 3 meses",
    between_3_and_6_months: "Entre 3 e 6 meses",
    between_6_and_12_months: "Entre 6 meses e 1 ano",
    more_than_1_year: "Mais de 1 ano",
  };
  return map[id] || id;
}

function getTeamSizeLabel(id: string): string {
  const map: Record<string, string> = {
    solo: "Somente eu",
    team_2_to_5: "De 2 a 5 pessoas",
    team_6_to_12: "De 6 a 12 pessoas",
    team_more_than_12: "Mais de 12 pessoas",
  };
  return map[id] || id;
}

function getCallSlotLabel(id: string): string {
  const map: Record<string, string> = {
    monday_15_16: "Segunda-feira, 15h às 16h",
    thursday_1830_1930: "Quinta-feira, 18h30 às 19h30",
  };
  return map[id] || "—";
}

// ─── Plant type colors ───────────────────────────────────────────────────────

function getPlantColor(plantType: string): string {
  const map: Record<string, string> = {
    broto_promissor: "oklch(0.65 0.18 145)",     // fresh green
    broto_em_risco: "oklch(0.60 0.15 60)",        // amber/yellow
    planta_em_tracao: "oklch(0.55 0.20 145)",     // strong green
    tracao_instavel: "oklch(0.60 0.18 30)",       // orange
    planta_escalavel: "oklch(0.45 0.22 145)",     // deep green
    gigante_exausta: "oklch(0.55 0.15 20)",       // reddish
  };
  return map[plantType] || "oklch(0.5 0.1 145)";
}

function getHealthColor(healthTier: string): string {
  return healthTier === "healthy" ? "oklch(0.55 0.20 145)" : "oklch(0.60 0.18 30)";
}

function getSizeColor(sizeTier: string): string {
  if (sizeTier === "large") return "oklch(0.50 0.18 250)";
  if (sizeTier === "medium") return "oklch(0.60 0.15 250)";
  return "oklch(0.70 0.10 250)";
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function Members() {
  const { user, isAuthenticated, loading } = useAuth();
  const [, navigate] = useLocation();
  const utils = trpc.useUtils();

  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => {
      utils.auth.me.invalidate();
      toast.success("Você saiu com sucesso.");
      navigate("/");
    },
  });

  // Fetch dashboard data
  const dashboardQuery = trpc.members.getDashboard.useQuery(undefined, {
    enabled: isAuthenticated === true,
  });

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      navigate("/");
      return;
    }
    if (user && user.onboardingCompleted === "false") {
      navigate("/onboarding");
    }
  }, [loading, isAuthenticated, user, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-foreground/20 border-t-foreground/60 rounded-full animate-spin" />
      </div>
    );
  }

  if (!user || user.onboardingCompleted === "false") {
    return null;
  }

  // ── Parse data ──
  const dashData = dashboardQuery.data;
  const surveyAnswers = dashData?.surveyAnswers ?? null;

  // Agency name with fallback rule
  const agencyName =
    surveyAnswers?.agencyName && surveyAnswers.agencyName.trim()
      ? surveyAnswers.agencyName
      : null;
  const agencyDisplay = agencyName || "sua agência";

  // Run the scoring engine
  let diagnostic: DiagnosticResult | null = null;
  if (surveyAnswers) {
    const parsed = parseSurveyAnswers(surveyAnswers);
    if (parsed) {
      diagnostic = calculateDiagnostic(parsed);
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header with logo */}
      <header className="fixed top-0 left-0 right-0 z-50 glass shadow-sm">
        <div className="container">
          <nav className="flex items-center justify-between h-16 md:h-[72px]">
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663539164565/SCcHJ9kMbHptCUSEK4niWe/logo-organick_9080e848.png"
              alt="Organick"
              className="h-8 md:h-9 w-auto"
            />
            <button
              onClick={() => logoutMutation.mutate()}
              disabled={logoutMutation.isPending}
              className="flex items-center gap-2 text-[14px] font-medium text-foreground/60 hover:text-foreground transition-colors"
            >
              <LogOut size={16} />
              {logoutMutation.isPending ? "Saindo..." : "Sair"}
            </button>
          </nav>
        </div>
      </header>

      <main className="pt-24 pb-24 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Page title — personalized */}
          <div className="mb-12 animate-fade-in-up">
            <p className="text-[12px] font-semibold tracking-[0.2em] uppercase text-foreground/40 mb-3">
              Área do membro
            </p>
            <h1 className="text-headline text-foreground">
              Diagnóstico {agencyName ? `da ${agencyName}` : ""}
            </h1>
          </div>

          {/* Main layout: Content on left, Plant on right */}
          <div className="grid lg:grid-cols-3 gap-8 lg:gap-12">
            {/* Left: Diagnostic content (2 cols) */}
            <div className="lg:col-span-2 space-y-6">

              {/* ── Plant Classification Card ── */}
              {diagnostic && (
                <div
                  className="rounded-3xl border shadow-sm shadow-black/5 p-8 animate-fade-in-up"
                  style={{
                    borderColor: getPlantColor(diagnostic.plantType),
                    background: `linear-gradient(135deg, white 0%, ${getPlantColor(diagnostic.plantType)}08 100%)`,
                  }}
                >
                  <div className="flex items-start gap-4 mb-4">
                    <div
                      className="w-12 h-12 rounded-2xl flex items-center justify-center shrink-0"
                      style={{ backgroundColor: `${getPlantColor(diagnostic.plantType)}20` }}
                    >
                      <Leaf size={22} style={{ color: getPlantColor(diagnostic.plantType) }} />
                    </div>
                    <div>
                      <p className="text-[11px] font-semibold tracking-[0.15em] uppercase text-foreground/40">
                        {agencyName ? `A planta da ${agencyName}` : "A planta da sua agência"}
                      </p>
                      <h2 className="text-[24px] font-bold tracking-tight text-foreground mt-0.5">
                        {diagnostic.plantLabel}
                      </h2>
                    </div>
                  </div>
                  <p className="text-[15px] text-foreground/60 leading-relaxed mb-6">
                    {diagnostic.plantDescription}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <span
                      className="inline-flex items-center px-3 py-1 rounded-full text-[12px] font-semibold"
                      style={{
                        backgroundColor: `${getSizeColor(diagnostic.sizeTier)}15`,
                        color: getSizeColor(diagnostic.sizeTier),
                      }}
                    >
                      Tamanho: {diagnostic.sizeTier === "small" ? "Pequena" : diagnostic.sizeTier === "medium" ? "Média" : "Grande"}
                    </span>
                    <span
                      className="inline-flex items-center px-3 py-1 rounded-full text-[12px] font-semibold"
                      style={{
                        backgroundColor: `${getHealthColor(diagnostic.healthTier)}15`,
                        color: getHealthColor(diagnostic.healthTier),
                      }}
                    >
                      Saúde: {diagnostic.healthTier === "healthy" ? "Saudável" : "Frágil"}
                    </span>
                  </div>
                </div>
              )}

              {/* ── Score Bars Card ── */}
              {diagnostic && (
                <div className="bg-white rounded-3xl border border-border shadow-sm shadow-black/5 p-8 animate-fade-in-up animate-delay-100">
                  <div className="flex items-start gap-4 mb-6">
                    <div className="w-12 h-12 rounded-2xl bg-foreground flex items-center justify-center shrink-0">
                      <Building2 size={20} className="text-background" />
                    </div>
                    <div>
                      <h2 className="text-[20px] font-semibold tracking-tight text-foreground">
                        {agencyName ? `O momento atual da ${agencyName}` : "O momento atual da sua agência"}
                      </h2>
                      <p className="text-[14px] text-foreground/50 mt-0.5">
                        {surveyAnswers?.agencyAgeRange
                          ? getAgencyAgeLabel(surveyAnswers.agencyAgeRange)
                          : ""}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-5">
                    <ProgressBar
                      label={agencyName ? `Saúde da ${agencyName}` : "Saúde da sua agência"}
                      value={diagnostic.healthScore}
                      maxValue={100}
                      color={getHealthColor(diagnostic.healthTier)}
                    />
                    <ProgressBar
                      label={agencyName ? `Tamanho da ${agencyName}` : "Tamanho da sua agência"}
                      value={diagnostic.sizeScore}
                      maxValue={100}
                      color={getSizeColor(diagnostic.sizeTier)}
                    />
                  </div>
                </div>
              )}

              {/* ── Info Cards Grid ── */}
              <div className="grid sm:grid-cols-2 gap-4">
                <InfoCard
                  icon={<Users size={18} />}
                  label="Equipe"
                  value={
                    surveyAnswers?.teamSizeRange
                      ? getTeamSizeLabel(surveyAnswers.teamSizeRange)
                      : "—"
                  }
                  delay="animate-delay-200"
                />
                <InfoCard
                  icon={<TrendingUp size={18} />}
                  label="Clientes atendidos"
                  value={
                    surveyAnswers?.clientCount
                      ? `${surveyAnswers.clientCount} clientes`
                      : "—"
                  }
                  delay="animate-delay-200"
                />
                <InfoCard
                  icon={<Building2 size={18} />}
                  label="Faturamento mensal"
                  value={
                    surveyAnswers?.monthlyRevenue
                      ? new Intl.NumberFormat("pt-BR", {
                          style: "currency",
                          currency: "BRL",
                          minimumFractionDigits: 0,
                        }).format(Number(surveyAnswers.monthlyRevenue))
                      : "—"
                  }
                  delay="animate-delay-300"
                />
                <InfoCard
                  icon={<Calendar size={18} />}
                  label="Call de onboarding"
                  value={
                    surveyAnswers?.onboardingCallSlot
                      ? getCallSlotLabel(surveyAnswers.onboardingCallSlot)
                      : "—"
                  }
                  delay="animate-delay-300"
                />
              </div>

              {/* ── Placeholder modules ── */}
              <div className="bg-white rounded-3xl border border-border shadow-sm shadow-black/5 p-8 animate-fade-in-up animate-delay-300">
                <p className="text-[12px] font-semibold tracking-[0.2em] uppercase text-foreground/40 mb-4">
                  Próximos passos
                </p>
                <div className="space-y-3">
                  <PlaceholderBlock label="Módulo 1 — Estrutura da agência" />
                  <PlaceholderBlock label="Módulo 2 — Captação de clientes" />
                  <PlaceholderBlock label="Módulo 3 — Processos internos" />
                </div>
              </div>
            </div>

            {/* Right: Plant image (1 col) */}
            <div className="hidden lg:flex flex-col items-center justify-start pt-8 animate-fade-in-up animate-delay-200">
              {diagnostic ? (
                <>
                  {/* Plant image — uses the image name from the scoring engine */}
                  <div className="w-56 h-72 flex items-center justify-center rounded-3xl bg-neutral-50 border border-border overflow-hidden">
                    <img
                      src={`/images/${diagnostic.plantImageName}`}
                      alt={diagnostic.plantLabel}
                      className="w-full h-full object-contain p-4"
                      onError={(e) => {
                        // Fallback if image not yet uploaded — show plant type text
                        const target = e.currentTarget;
                        target.style.display = "none";
                        const parent = target.parentElement;
                        if (parent) {
                          parent.innerHTML = `
                            <div class="flex flex-col items-center justify-center h-full px-4">
                              <div class="w-12 h-12 rounded-full bg-neutral-100 flex items-center justify-center mb-3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-foreground/40"><path d="M11 20A7 7 0 0 1 9.8 6.9C15.5 4.9 17 3.5 17 3.5s1 1 1 3c0 2.2-2 4-4 5"/><path d="M11.7 10.4a7.03 7.03 0 0 1 9.3 6.1c0 3.9-3.1 7-7 7"/></svg>
                              </div>
                              <p class="text-[14px] font-semibold text-foreground/60 text-center">${diagnostic.plantLabel}</p>
                              <p class="text-[11px] text-foreground/30 mt-1">Imagem em breve</p>
                            </div>
                          `;
                        }
                      }}
                    />
                  </div>
                  <p className="text-[15px] font-semibold text-foreground mt-4 text-center">
                    {diagnostic.plantLabel}
                  </p>
                  <p className="text-[13px] text-foreground/40 text-center mt-1 max-w-[200px]">
                    {agencyName
                      ? `A planta da ${agencyName}`
                      : "A planta da sua agência"}
                  </p>
                </>
              ) : (
                <>
                  <div className="w-56 h-72 flex items-center justify-center rounded-3xl bg-neutral-50 border border-border">
                    <Leaf size={48} className="text-foreground/20" />
                  </div>
                  <p className="text-[13px] text-foreground/40 text-center mt-4">
                    Carregando diagnóstico...
                  </p>
                </>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

// ─── Sub-components ──────────────────────────────────────────────────────────

function InfoCard({
  icon,
  label,
  value,
  delay,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  delay: string;
}) {
  return (
    <div
      className={`bg-white rounded-2xl border border-border shadow-sm shadow-black/5 p-5 animate-fade-in-up ${delay}`}
    >
      <div className="flex items-center gap-3 mb-2">
        <div className="w-8 h-8 rounded-lg bg-neutral-100 flex items-center justify-center text-foreground/50">
          {icon}
        </div>
        <span className="text-[11px] font-semibold tracking-[0.15em] uppercase text-foreground/40">
          {label}
        </span>
      </div>
      <p className="text-[16px] font-semibold text-foreground">{value}</p>
    </div>
  );
}

function PlaceholderBlock({ label }: { label: string }) {
  return (
    <div className="flex items-center gap-4 p-4 rounded-2xl border border-border hover:border-foreground/20 transition-colors">
      <div className="w-10 h-10 rounded-xl bg-neutral-100 shrink-0" />
      <div className="flex-1">
        <p className="text-[14px] font-medium text-foreground">{label}</p>
        <p className="text-[12px] text-foreground/40 mt-0.5">Em breve</p>
      </div>
      <div className="px-3 py-1 rounded-full bg-neutral-100 text-[11px] font-semibold text-foreground/40 uppercase tracking-wider">
        Bloqueado
      </div>
    </div>
  );
}

/**
 * AGENCY DIAGNOSTIC SCORING ENGINE
 *
 * Calculates Plant Size and Plant Health from onboarding survey answers.
 * Produces one of 6 final plant types based on the combination of
 * 3 size tiers × 2 health tiers.
 */

// ─── Types ───────────────────────────────────────────────────────────────────

export type AgencyAgeRange =
  | "less_than_3_months"
  | "between_3_and_6_months"
  | "between_6_and_12_months"
  | "more_than_1_year";

export type TeamSizeRange =
  | "solo"
  | "team_2_to_5"
  | "team_6_to_12"
  | "team_more_than_12";

export type OnboardingCallSlot = "monday_15_16" | "thursday_1830_1930";

export type SizeTier = "small" | "medium" | "large";
export type HealthTier = "fragile" | "healthy";

export type PlantType =
  | "broto_promissor"
  | "broto_em_risco"
  | "planta_em_tracao"
  | "tracao_instavel"
  | "planta_escalavel"
  | "gigante_exausta";

export interface DiagnosticInput {
  agencyAgeRange: AgencyAgeRange;
  teamSizeRange: TeamSizeRange;
  clientCount: number;
  monthlyRevenue: number;
}

export interface DiagnosticResult {
  sizeScore: number;       // 0–100
  healthScore: number;     // 0–100
  sizeTier: SizeTier;
  healthTier: HealthTier;
  plantType: PlantType;
  plantLabel: string;      // Portuguese display name
  plantDescription: string; // Portuguese explanation
  plantImageName: string;  // File name for the plant image
}

// ─── Score Tables ────────────────────────────────────────────────────────────

// A. agencyAgeRange
const AGE_SIZE: Record<AgencyAgeRange, number> = {
  less_than_3_months: 10,
  between_3_and_6_months: 25,
  between_6_and_12_months: 45,
  more_than_1_year: 70,
};

const AGE_HEALTH: Record<AgencyAgeRange, number> = {
  less_than_3_months: 60,
  between_3_and_6_months: 58,
  between_6_and_12_months: 60,
  more_than_1_year: 62,
};

// B. teamSizeRange
const TEAM_SIZE: Record<TeamSizeRange, number> = {
  solo: 10,
  team_2_to_5: 35,
  team_6_to_12: 65,
  team_more_than_12: 90,
};

const TEAM_HEALTH: Record<TeamSizeRange, number> = {
  solo: 62,
  team_2_to_5: 60,
  team_6_to_12: 52,
  team_more_than_12: 45,
};

// C. clientCount ranges
function getClientSizeScore(count: number): number {
  if (count <= 2) return 10;
  if (count <= 5) return 25;
  if (count <= 10) return 45;
  if (count <= 20) return 70;
  return 90;
}

function getClientHealthScore(count: number): number {
  if (count <= 2) return 55;
  if (count <= 5) return 62;
  if (count <= 10) return 68;
  if (count <= 20) return 60;
  return 48;
}

// D. monthlyRevenue ranges
function getRevenueSizeScore(revenue: number): number {
  if (revenue <= 5000) return 10;
  if (revenue <= 15000) return 25;
  if (revenue <= 30000) return 45;
  if (revenue <= 60000) return 70;
  return 90;
}

function getRevenueHealthScore(revenue: number): number {
  if (revenue <= 5000) return 40;
  if (revenue <= 15000) return 52;
  if (revenue <= 30000) return 65;
  if (revenue <= 60000) return 75;
  return 80;
}

// ─── Weights ─────────────────────────────────────────────────────────────────

// Size Score weights
const SIZE_WEIGHTS = {
  agencyAgeRange: 0.10,
  teamSizeRange: 0.20,
  clientCount: 0.30,
  monthlyRevenue: 0.40,
};

// Health Score weights
const HEALTH_WEIGHTS = {
  agencyAgeRange: 0.10,
  teamSizeRange: 0.20,
  clientCount: 0.20,
  monthlyRevenue: 0.50,
};

// ─── Tier Classification ─────────────────────────────────────────────────────

function getSizeTier(score: number): SizeTier {
  if (score <= 34) return "small";
  if (score <= 69) return "medium";
  return "large";
}

function getHealthTier(score: number): HealthTier {
  if (score <= 54) return "fragile";
  return "healthy";
}

// ─── Plant Type Map ──────────────────────────────────────────────────────────

interface PlantInfo {
  type: PlantType;
  label: string;
  description: string;
  imageName: string;
}

const PLANT_MAP: Record<string, PlantInfo> = {
  "small_healthy": {
    type: "broto_promissor",
    label: "Broto Promissor",
    description: "Agência pequena, mas com sinais saudáveis e grande potencial de crescimento.",
    imageName: "plant-broto-promissor.png",
  },
  "small_fragile": {
    type: "broto_em_risco",
    label: "Broto em Risco",
    description: "Agência pequena, ainda vulnerável e instável.",
    imageName: "plant-broto-em-risco.png",
  },
  "medium_healthy": {
    type: "planta_em_tracao",
    label: "Planta em Tração",
    description: "Agência em crescimento com estrutura relativamente saudável.",
    imageName: "plant-planta-em-tracao.png",
  },
  "medium_fragile": {
    type: "tracao_instavel",
    label: "Tração Instável",
    description: "Agência em crescimento, mas com estrutura fraca ou instabilidade.",
    imageName: "plant-tracao-instavel.png",
  },
  "large_healthy": {
    type: "planta_escalavel",
    label: "Planta Escalável",
    description: "Agência robusta com crescimento forte e operação saudável.",
    imageName: "plant-planta-escalavel.png",
  },
  "large_fragile": {
    type: "gigante_exausta",
    label: "Gigante Exausta",
    description: "Agência grande com volume e escala, mas com saúde interna comprometida.",
    imageName: "plant-gigante-exausta.png",
  },
};

// ─── Main Scoring Function ───────────────────────────────────────────────────

export function calculateDiagnostic(input: DiagnosticInput): DiagnosticResult {
  const { agencyAgeRange, teamSizeRange, clientCount, monthlyRevenue } = input;

  // ── Step 1: Raw weighted size score ──
  const sizeScore = Math.round(
    AGE_SIZE[agencyAgeRange] * SIZE_WEIGHTS.agencyAgeRange +
    TEAM_SIZE[teamSizeRange] * SIZE_WEIGHTS.teamSizeRange +
    getClientSizeScore(clientCount) * SIZE_WEIGHTS.clientCount +
    getRevenueSizeScore(monthlyRevenue) * SIZE_WEIGHTS.monthlyRevenue
  );

  // ── Step 2: Raw weighted health score ──
  let healthScore =
    AGE_HEALTH[agencyAgeRange] * HEALTH_WEIGHTS.agencyAgeRange +
    TEAM_HEALTH[teamSizeRange] * HEALTH_WEIGHTS.teamSizeRange +
    getClientHealthScore(clientCount) * HEALTH_WEIGHTS.clientCount +
    getRevenueHealthScore(monthlyRevenue) * HEALTH_WEIGHTS.monthlyRevenue;

  // ── Step 3: Health adjustments ──

  // Derived variable: revenuePerClient
  const revenuePerClient = clientCount > 0 ? monthlyRevenue / clientCount : null;

  // Positive adjustments
  if (
    agencyAgeRange === "less_than_3_months" &&
    clientCount <= 2 &&
    monthlyRevenue <= 5000
  ) {
    healthScore += 10;
  }

  if (revenuePerClient !== null && revenuePerClient >= 6000) {
    healthScore += 10;
  }

  if (teamSizeRange === "solo" && monthlyRevenue > 30000) {
    healthScore += 10;
  }

  // Negative adjustments
  if (
    (teamSizeRange === "team_6_to_12" || teamSizeRange === "team_more_than_12") &&
    monthlyRevenue <= 15000
  ) {
    healthScore -= 15;
  }

  if (clientCount >= 21 && monthlyRevenue <= 30000) {
    healthScore -= 15;
  }

  if (revenuePerClient !== null && revenuePerClient < 3000) {
    healthScore -= 10;
  }

  // Clamp health to 0–100
  healthScore = Math.round(Math.max(0, Math.min(100, healthScore)));

  // ── Step 4: Determine tiers ──
  const sizeTier = getSizeTier(sizeScore);
  const healthTier = getHealthTier(healthScore);

  // ── Step 5: Map to plant type ──
  const key = `${sizeTier}_${healthTier}`;
  const plant = PLANT_MAP[key]!;

  return {
    sizeScore,
    healthScore,
    sizeTier,
    healthTier,
    plantType: plant.type,
    plantLabel: plant.label,
    plantDescription: plant.description,
    plantImageName: plant.imageName,
  };
}

// ─── Helper: Parse raw survey answers into DiagnosticInput ───────────────────

export function parseSurveyAnswers(answers: Record<string, string>): DiagnosticInput | null {
  if (
    !answers.agencyAgeRange ||
    !answers.teamSizeRange ||
    answers.clientCount === undefined ||
    answers.monthlyRevenue === undefined
  ) {
    return null;
  }

  return {
    agencyAgeRange: answers.agencyAgeRange as AgencyAgeRange,
    teamSizeRange: answers.teamSizeRange as TeamSizeRange,
    clientCount: parseInt(answers.clientCount, 10) || 0,
    monthlyRevenue: parseInt(answers.monthlyRevenue, 10) || 0,
  };
}
